.. spelling::

    Leathers

.. index:: warnings ; Leathers

.. _pkg.Leathers:

Leathers
========

-  `Official <https://github.com/ruslo/leathers>`__

.. literalinclude:: /../examples/Leathers/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

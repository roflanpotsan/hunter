.. spelling::

    Android
    ARM64
    v8a
    System
    Image

.. index:: android_sdk_component ; Android-ARM64-v8a-System-Image

.. _pkg.Android-ARM64-v8a-System-Image:

Android-ARM64-v8a-System-Image
==============================

-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/Android-ARM64-v8a-System-Image/CMakeLists.txt>`__

.. literalinclude:: /../examples/Android-ARM64-v8a-System-Image/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

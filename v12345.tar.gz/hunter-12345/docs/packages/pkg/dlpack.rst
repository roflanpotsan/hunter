.. spelling::

    dlpack

.. index::
  single: unsorted ; dlpack

.. _pkg.dlpack:

dlpack
======

-  `Official GitHub <https://github.com/dmlc/dlpack>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/dlpack/CMakeLists.txt>`__

.. literalinclude:: /../examples/dlpack/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

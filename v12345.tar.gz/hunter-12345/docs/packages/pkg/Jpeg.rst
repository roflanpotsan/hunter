.. spelling::

    Jpeg

.. index:: media ; Jpeg

.. _pkg.Jpeg:

Jpeg
====

-  `Official <http://www.ijg.org/>`__
-  `Hunterized <https://github.com/hunter-packages/jpeg>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/Jpeg/CMakeLists.txt>`__

.. literalinclude:: /../examples/Jpeg/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

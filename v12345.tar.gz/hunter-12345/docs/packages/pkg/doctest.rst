.. spelling::

    doctest

.. index:: unsorted ; doctest

.. _pkg.doctest:

doctest
=======

.. |hunter| image:: https://img.shields.io/badge/hunter-v0.18.29-blue.svg
  :target: https://github.com/cpp-pm/hunter/releases/tag/v0.18.29
  :alt: Hunter v0.18.29

-  `Official <https://github.com/onqtam/doctest>`__
- Available since |hunter|

.. literalinclude:: /../examples/doctest/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

.. spelling::

    cgltf

.. index::
  single: unsorted ; cgltf

.. _pkg.cgltf:

cgltf
=====

-  `Official <https://github.com/jkuhlmann/cgltf>`__
-  `Hunterized <https://github.com/cpp-pm/cgltf>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/cgltf/CMakeLists.txt>`__
-  Added by `Rahul Sheth <https://github.com/rbsheth>`__ (`pr-275 <https://github.com/cpp-pm/hunter/pull/275>`__)

.. literalinclude:: /../examples/cgltf/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

.. spelling::

    mng

.. index:: unsorted ; mng

.. _pkg.mng:

mng
===

- https://sourceforge.net/projects/libmng/
- `Hunterized <https://github.com/hunter-packages/mng>`__
- `Example <https://github.com/cpp-pm/hunter/blob/master/examples/mng/CMakeLists.txt>`__

.. literalinclude:: /../examples/mng/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

.. spelling::

    duktape

.. index:: unsorted ; duktape

.. _pkg.duktape:

duktape
=======

- http://duktape.org/
- `Hunterized <https://github.com/hunter-packages/duktape>`__
- `Example <https://github.com/cpp-pm/hunter/blob/master/examples/duktape/CMakeLists.txt>`__

.. literalinclude:: /../examples/duktape/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

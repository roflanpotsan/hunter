.. spelling::
    lehrfempp
    
.. index::
  single: math ; lehrfempp

.. _pkg.lehrfempp:

lehrfempp
=========

-  `Official <https://github.com/craffael/lehrfempp>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/lehrfempp/CMakeLists.txt>`__
-  Added by `craffael <https://github.com/craffael>`__ (`pr-1629 <https://github.com/ruslo/hunter/pull/1629>`__)

.. literalinclude:: /../examples/lehrfempp/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

.. spelling::

    cmcstl

.. index:: unsorted ; cmcstl2

.. _pkg.cmcstl2:

cmcstl2
=======

-  `Official <https://github.com/CaseyCarter/cmcstl2>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/cmcstl2/CMakeLists.txt>`__
-  Added by `dvirtz <https://github.com/dvirtz>`__ (`pr-1801 <https://github.com/ruslo/hunter/pull/1801>`__)

.. literalinclude:: /../examples/cmcstl2/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

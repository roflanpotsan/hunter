.. spelling::

    CreateLaunchers

.. index:: cmake_modules ; CreateLaunchers

.. _pkg.CreateLaunchers:

CreateLaunchers
===============

-  `Official GitHub <https://github.com/caseymcc/CreateLaunchers>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/CreateLaunchers/CMakeLists.txt>`__

.. literalinclude:: /../examples/CreateLaunchers/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

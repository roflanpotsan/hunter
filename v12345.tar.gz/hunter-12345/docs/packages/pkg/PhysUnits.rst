.. spelling::

    PhysUnits

.. index::
  single: frameworks ; PhysUnits

.. _pkg.PhysUnits:

PhysUnits
=========

-  `Official <https://github.com/martinmoene/PhysUnits-CT-Cpp11>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/PhysUnits/CMakeLists.txt>`__
-  Added by `Stefan Reinhold <https://github.com/ithron>`__ (`pr-1503 <https://github.com/ruslo/hunter/pull/1503>`__)

.. literalinclude:: /../examples/PhysUnits/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }


.. spelling::

    dynalo

.. index:: os ; dynalo

.. _pkg.dynalo:

dynalo
======

-  `Official <https://github.com/maddouri/dynalo>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/dynalo/CMakeLists.txt>`__
-  Added by `Yassine Maddouri <https://github.com/maddouri>`__ (`pr-1350 <https://github.com/ruslo/hunter/pull/1350>`__)

.. literalinclude:: /../examples/dynalo/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
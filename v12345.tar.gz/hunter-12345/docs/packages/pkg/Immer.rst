.. spelling::

    Immer

.. index::
  single: unsorted ; Immer

.. _pkg.Immer:

Immer
=====

-  `Official <https://github.com/arximboldi/immer>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/Immer/CMakeLists.txt>`__
-  Added by `Joerg-Christian Boehme <https://github.com/Bjoe>`__ (`pr-104 <https://github.com/cpp-pm/hunter/pull/104>`__)

.. literalinclude:: /../examples/Immer/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

.. spelling::

    KTX

.. index::
  single: unsorted ; KTX-Software

.. _pkg.KTX-Software:

KTX-Software
============

-  `Official <https://github.com/KhronosGroup/KTX-Software>`__
-  `Hunterized <https://github.com/cpp-pm/KTX-Software>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/KTX-Software/CMakeLists.txt>`__
-  Added by `Rahul Sheth <https://github.com/rbsheth>`__ (`pr-435 <https://github.com/cpp-pm/hunter/pull/435>`__)

.. literalinclude:: /../examples/KTX-Software/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

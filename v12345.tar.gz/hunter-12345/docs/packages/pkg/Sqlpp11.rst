.. spelling::

    Sqlpp

.. index::
  single: database ; Sqlpp11

.. _pkg.Sqlpp11:

Sqlpp11
=======

-  `Official <https://github.com/rbock/sqlpp11>`__
-  `Hunterized <https://github.com/hunter-packages/sqlpp11>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/Sqlpp11/CMakeLists.txt>`__
-  Added by `xsacha <https://github.com/xsacha>`__ (`pr-1786 <https://github.com/ruslo/hunter/pull/1786>`__)

.. literalinclude:: /../examples/Sqlpp11/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

.. spelling::

    ittapi

.. index::
  single: testing ; ittapi

.. _pkg.ittapi:

ittapi
======

-  `Official <https://github.com/intel/ittapi>`__
-  `Hunterized <https://github.com/cpp-pm/ittapi>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/ittapi/CMakeLists.txt>`__
-  Added by `Raffael Casagrande <https://github.com/craffael>`__ (`pr-483 <https://github.com/cpp-pm/hunter/pull/483>`__)

.. literalinclude:: /../examples/ittapi/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

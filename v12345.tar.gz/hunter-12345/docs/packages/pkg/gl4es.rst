.. spelling::

    gl4es
    gl

.. index::
  single: graphics ; gl4es

.. _pkg.gl4es:

gl4es
=====

-  `Official <https://github.com/ptitSeb/gl4es>`__
-  `Hunterized <https://github.com/cpp-pm/gl4es>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/gl4es/CMakeLists.txt>`__
-  Added by `drodin <https://github.com/drodin>`__ (`pr-143 <https://github.com/cpp-pm/hunter/pull/143>`__)

.. literalinclude:: /../examples/gl4es/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

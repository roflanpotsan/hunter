Compiler
--------

 - :ref:`pkg.ctti` - Compile Time Type Information for the C++ programming language.
 - :ref:`pkg.bison` - general-purpose parser generator.
 - :ref:`pkg.flex` - a tool for generating scanners.
 - :ref:`pkg.LLVM` - collection of modular and reusable compiler and toolchain technologies.

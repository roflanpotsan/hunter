* TODO
* [Toolchain verification](https://github.com/ruslo/hunter/wiki/Rationale-%28toolchain-verification%29)

### X

* download before first command parsed (need for proper `find_package` command work or external cmake libs)
* internal projects must see each other (forward `<LIB>_ROOT` variable)

### Synchronization

* TODO
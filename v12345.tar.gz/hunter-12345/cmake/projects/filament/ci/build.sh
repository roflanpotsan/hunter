# Install packages
sudo apt-get install -y libgl1-mesa-dev

bash .github/workflows/ci/build.sh

<!--- If you have a trivial question you can ask it in Gitter room: https://gitter.im/cpp-pm/hunter -->

* I've read [Brief overview section](https://hunter.readthedocs.io/en/latest/overview.html) and do understand basic concepts. **[Yes|No]**
* I've read [F.A.Q. section](https://hunter.readthedocs.io/en/latest/faq.html) and haven't found an answer to my question. **[Yes|No]**
* I've read [Code of Conduct](https://github.com/cpp-pm/hunter/blob/master/.github/CODE_OF_CONDUCT.md), I promise to be polite and will do my best at being constructive. **[Yes|No]**

---
